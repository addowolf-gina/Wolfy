# WOLFY storefront starter

A free static storefront starter for Cloudflare Pages.

## Files
- `index.html` — page structure
- `style.css` — responsive black / silver / orange theme
- `app.js` — demo products, search, categories and cart

## Deploy on Cloudflare Pages
1. Upload these files to a GitHub repository (the three files must be at the repository root).
2. In Cloudflare, open **Workers & Pages** → **Create** → **Pages** → **Connect to Git**.
3. Select the WOLFY repository and deploy with:
   - Framework preset: None
   - Build command: leave blank (or `exit 0` if required)
   - Build output directory: `/` (root)
4. Cloudflare will provide a free `*.pages.dev` address, if available.

## Important
This is a visual storefront prototype. Products and prices are illustrative placeholders, not live supplier offers. The cart is local to the visitor's browser. Checkout intentionally does not collect payment or create orders. Before taking real orders, add a secure backend, a payment provider, supplier agreements/API, stock and shipping integrations, customer service, privacy/terms/refund policies, and tax handling. Third-party payment and shipping services may charge fees. Do not store payment card details in this static site.
