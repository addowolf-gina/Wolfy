const products = [
 {id:1,name:"Pocket Bluetooth Speaker",category:"Tech",price:19.95,emoji:"🔊",desc:"Small size, big everyday sound."},
 {id:2,name:"Ambient LED Light",category:"Home",price:14.50,emoji:"💡",desc:"Add a warm glow to your space."},
 {id:3,name:"Everyday Crossbody Bag",category:"Accessories",price:22.00,emoji:"👜",desc:"A simple grab-and-go essential."},
 {id:4,name:"Smart Desk Organizer",category:"Home",price:16.75,emoji:"🗂️",desc:"Keep your workspace in order."},
 {id:5,name:"Wireless Earbuds Case",category:"Tech",price:12.95,emoji:"🎧",desc:"A compact audio companion."},
 {id:6,name:"Minimal Steel Bottle",category:"Lifestyle",price:18.25,emoji:"🥤",desc:"A reusable everyday bottle."},
 {id:7,name:"Classic Sunglasses",category:"Accessories",price:15.00,emoji:"🕶️",desc:"An easy finishing touch."},
 {id:8,name:"Portable Mini Fan",category:"Tech",price:13.95,emoji:"🌀",desc:"A little breeze when you need it."}
];
let cart = [];
let category = "All";
const euro = n => new Intl.NumberFormat("en-IE",{style:"currency",currency:"EUR"}).format(n);
function renderProducts(query=""){
 const list=products.filter(p=>(category==="All"||p.category===category)&&(`${p.name} ${p.category} ${p.desc}`.toLowerCase().includes(query.toLowerCase())));
 document.getElementById("resultCount").textContent=`${list.length} finds`;
 document.getElementById("products").innerHTML=list.map(p=>`<article class="product"><div class="product-art">${p.emoji}</div><div class="product-info"><span class="category">${p.category}</span><h3>${p.name}</h3><p class="desc">${p.desc}</p><div class="price-row"><span class="price">${euro(p.price)}</span><button class="add" data-add="${p.id}" aria-label="Add ${p.name} to cart">+</button></div></div></article>`).join("")||'<p class="muted">No products found. Try another search.</p>';
}
function renderCart(){
 document.getElementById("cartCount").textContent=cart.reduce((s,x)=>s+x.qty,0);
 document.getElementById("cartTotal").textContent=euro(cart.reduce((s,x)=>s+x.price*x.qty,0));
 document.getElementById("cartItems").innerHTML=cart.length?cart.map(x=>`<div class="cart-line"><span>${x.emoji} ${x.name} × ${x.qty}</span><strong>${euro(x.price*x.qty)}</strong><button data-remove="${x.id}">Remove</button></div>`).join(""):'<p class="muted">Your cart is empty.</p>';
}
document.addEventListener("click",e=>{
 const add=e.target.closest("[data-add]"); if(add){const p=products.find(x=>x.id===Number(add.dataset.add));const item=cart.find(x=>x.id===p.id);item?item.qty++:cart.push({...p,qty:1});renderCart();}
 const rem=e.target.closest("[data-remove]");if(rem){cart=cart.filter(x=>x.id!==Number(rem.dataset.remove));renderCart();}
 const chip=e.target.closest("[data-category]");if(chip){category=chip.dataset.category;document.querySelectorAll(".chip").forEach(c=>c.classList.toggle("active",c===chip));renderProducts(document.getElementById("searchInput").value);}
});
const panel=document.getElementById("cartPanel"),overlay=document.getElementById("overlay");
function toggleCart(open){panel.classList.toggle("open",open);overlay.classList.toggle("show",open);}
document.getElementById("cartOpen").onclick=()=>toggleCart(true);document.getElementById("cartClose").onclick=()=>toggleCart(false);overlay.onclick=()=>toggleCart(false);
document.getElementById("searchForm").addEventListener("submit",e=>e.preventDefault());
document.getElementById("searchInput").addEventListener("input",e=>renderProducts(e.target.value));
document.getElementById("checkout").onclick=()=>alert("WOLFY checkout is not connected yet. No payment will be taken. A secure payment provider and supplier/shipping integrations must be configured before accepting real orders.");
document.getElementById("newsletterForm").addEventListener("submit",e=>{e.preventDefault();document.getElementById("newsletterNote").textContent="Thanks! Newsletter signup will be connected when an email service is added.";e.target.reset();});
document.getElementById("year").textContent=new Date().getFullYear();
renderProducts();renderCart();